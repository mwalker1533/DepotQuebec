# -*- coding: utf-8 -*-
"""
default.py — Entry point for Noovo Kodi addon.
Python 3 / Kodi 20+ compatible.
"""

import sys
import urllib.parse

from resources.lib import navig


def main():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))

    action = params.get('action', '')

    if action == 'shows':
        category = params.get('category')
        navig.show_shows(category)

    elif action == 'episodes':
        show_id = params.get('show_id', '')
        if show_id:
            navig.show_episodes(show_id)

    elif action == 'play':
        brightcove_id = params.get('brightcove_id', '')
        if brightcove_id:
            navig.play_video(brightcove_id)

    else:
        navig.show_main_menu()


if __name__ == '__main__':
    main()
