# -*- coding: utf-8 -*-
"""
http.py — HTTP utility for Noovo Kodi addon.
Python 3 / Kodi 20+ compatible.
"""

import json
import urllib.request
import urllib.error
import xbmc

REQUEST_TIMEOUT = 15

DEFAULT_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/html, */*',
    'Accept-Language': 'fr-CA,fr;q=0.9,en;q=0.8',
    'Origin': 'https://noovo.ca',
    'Referer': 'https://noovo.ca/',
}


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[Noovo] {msg}', level)


def get(url, is_json=False, extra_headers=None):
    """
    Perform a GET request. Returns string, dict/list, or None on error.
    """
    headers = dict(DEFAULT_HEADERS)
    if extra_headers:
        headers.update(extra_headers)

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            raw = resp.read().decode('utf-8')
            if is_json:
                return json.loads(raw)
            return raw

    except urllib.error.HTTPError as e:
        _log(f'HTTP {e.code} error: {url} — {e.reason}', xbmc.LOGERROR)
    except urllib.error.URLError as e:
        _log(f'URL error: {url} — {e.reason}', xbmc.LOGERROR)
    except json.JSONDecodeError as e:
        _log(f'JSON error: {url} — {e}', xbmc.LOGERROR)
    except Exception as e:
        _log(f'Unexpected error: {url} — {e}', xbmc.LOGERROR)

    return None
