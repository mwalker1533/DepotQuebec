# -*- coding: utf-8 -*-
"""
navig.py — Navigation and playback for Noovo Kodi addon.
Python 3 / Kodi 20+ compatible.

Fixes:
- xbmcvfs.translatePath used correctly (was deprecated in issue #7 log)
- NoneType crash on jouer_video fixed via safe Brightcove API
- Proper error dialogs instead of silent failures
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from resources.lib import scrapper

ADDON = xbmcaddon.Addon()
PLUGIN_URL = sys.argv[0]
PLUGIN_HANDLE = int(sys.argv[1])

# Use xbmcvfs.translatePath (replaces deprecated xbmc.translatePath)
ADDON_DATA_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[Noovo] {msg}', level)


def _show_error(msg):
    xbmcgui.Dialog().ok('Noovo', msg)


def build_url(params):
    return PLUGIN_URL + '?' + urllib.parse.urlencode(params)


def add_directory(label, params, art=None, info=None, is_folder=True):
    url = build_url(params)
    li = xbmcgui.ListItem(label)
    if art:
        li.setArt(art)
    if info:
        li.setInfo('video', info)
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, li, is_folder)


def show_main_menu():
    """Show main categories menu."""
    categories = scrapper.get_categories()

    if not categories:
        _show_error('Impossible de charger le menu.\nVérifiez votre connexion internet.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for cat in categories:
        add_directory(
            label=cat['title'],
            params={'action': 'shows', 'category': cat['id']},
            art={'thumb': cat.get('thumb', ''), 'icon': cat.get('thumb', '')},
            info={'title': cat['title']},
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_shows(category=None):
    """List shows, optionally filtered by category."""
    shows = scrapper.get_shows(category)

    if not shows:
        _show_error('Aucune émission disponible.\nVérifiez votre connexion internet.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for show in shows:
        add_directory(
            label=show['title'],
            params={'action': 'episodes', 'show_id': show['id']},
            art={'thumb': show['thumb'], 'fanart': show['thumb']},
            info={
                'title': show['title'],
                'plot': show['description'],
                'mediatype': 'tvshow',
            },
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'tvshows')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_episodes(show_id):
    """List episodes for a show."""
    episodes = scrapper.get_episodes(show_id)

    if not episodes:
        _show_error(
            'Aucun épisode disponible pour cette émission.\n'
            'Le contenu a peut-être été retiré ou nécessite un abonnement.'
        )
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for ep in episodes:
        label = ep['title']
        if ep['season'] and ep['episode']:
            label = f'S{ep["season"]:02d}E{ep["episode"]:02d} - {ep["title"]}'

        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        li.setArt({'thumb': ep['thumb'], 'fanart': ep['thumb']})
        li.setInfo('video', {
            'title': ep['title'],
            'plot': ep['description'],
            'season': ep['season'],
            'episode': ep['episode'],
            'duration': ep['duration'],
            'mediatype': 'episode',
        })

        url = build_url({'action': 'play', 'brightcove_id': ep['brightcove_id']})
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, li, False)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'episodes')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def play_video(brightcove_id):
    """
    Resolve and play a Noovo video via Brightcove.

    This replaces the old jouer_video() which crashed with:
    TypeError: 'NoneType' object has no attribute '__getitem__'
    because it tried to read video['data-video-id'] from scraped HTML
    that had already changed structure.
    """
    _log(f'Playing Brightcove video: {brightcove_id}')

    stream_url = scrapper.get_stream_url(brightcove_id)

    if not stream_url:
        _show_error(
            'Impossible de lire cette vidéo.\n'
            'Le contenu est peut-être réservé aux abonnés,\n'
            'ou n\'est plus disponible sur Noovo.'
        )
        xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'mediatype': 'video'})

    # Use InputStream Adaptive for HLS streams (better quality/compatibility)
    if '.m3u8' in stream_url:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, li)
