# -*- coding: utf-8 -*-
"""
navig.py — Navigation and playback for ICI Tou.TV Kodi addon.
Python 3 / Kodi 20+ compatible.
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import scrapper

ADDON = xbmcaddon.Addon()
PLUGIN_URL = sys.argv[0]
PLUGIN_HANDLE = int(sys.argv[1])


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[Tou.TV] {msg}', level)


def _show_error(msg):
    """Show a user-friendly error dialog in French."""
    xbmcgui.Dialog().ok('ICI Tou.TV', msg)


def build_url(params):
    return PLUGIN_URL + '?' + urllib.parse.urlencode(params)


def add_directory(label, params, art=None, info=None, is_folder=True, add_favourite=False):
    url = build_url(params)
    li = xbmcgui.ListItem(label)
    if art:
        li.setArt(art)
    if info:
        li.setInfo('video', info)
    if add_favourite:
        li.addContextMenuItems([
            (f'Ajouter "{label}" aux favoris', 'Action(AddFavourite)')
        ])
    xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, li, is_folder)


def show_main_menu():
    """Main menu: categories + quick access to all shows."""
    categories = scrapper.get_categories()

    if not categories:
        # Fallback if API is down — still show an "All Shows" entry
        add_directory(
            'Toutes les émissions',
            {'action': 'shows'},
            art={'icon': ADDON.getAddonInfo('icon')}
        )
    else:
        for cat in categories:
            add_directory(
                cat['title'],
                {'action': 'shows', 'category_id': cat['id']},
                art={'thumb': cat.get('thumb', ''), 'icon': cat.get('thumb', '')},
                info={'title': cat['title']},
            )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_shows(category_id=None):
    """List shows, optionally filtered by category."""
    shows = scrapper.get_shows(category_id)

    if not shows:
        _show_error('Aucune émission disponible pour le moment.\nVérifiez votre connexion internet.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for show in shows:
        add_directory(
            show['title'],
            {'action': 'episodes', 'show_id': show['id']},
            art={'thumb': show['thumb'], 'fanart': show['thumb']},
            info={
                'title': show['title'],
                'plot': show['description'],
                'mediatype': 'tvshow',
            },
            add_favourite=True,
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'tvshows')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_episodes(show_id):
    """List episodes for a show."""
    episodes = scrapper.get_episodes(show_id)

    if not episodes:
        _show_error('Aucun épisode disponible.\nCette émission n\'a peut-être pas de contenu gratuit.')
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for ep in episodes:
        label = ep['title']
        if ep['season'] and ep['episode']:
            label = f'S{ep["season"]:02d}E{ep["episode"]:02d} - {ep["title"]}'

        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        li.setArt({'thumb': ep['thumb'], 'fanart': ep['thumb']})
        li.setInfo('video', {
            'title': ep['title'],
            'plot': ep['description'],
            'season': ep['season'],
            'episode': ep['episode'],
            'duration': ep['duration'],
            'mediatype': 'episode',
        })

        url = build_url({'action': 'play', 'media_id': ep['id']})
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, url, li, False)

    xbmcplugin.setContent(PLUGIN_HANDLE, 'episodes')
    xbmcplugin.addSortMethod(PLUGIN_HANDLE, xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def play_video(media_id):
    """Resolve and play a video."""
    _log(f'Playing media_id={media_id}')

    stream_url = scrapper.get_stream_url(media_id)

    if not stream_url:
        _show_error(
            'Impossible de lire cette vidéo.\n'
            'Le contenu est peut-être réservé aux abonnés Extra,\n'
            'ou n\'est plus disponible.'
        )
        xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, False, xbmcgui.ListItem())
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'mediatype': 'video'})

    # Use InputStream Adaptive for HLS streams
    if '.m3u8' in stream_url:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
    elif '.mpd' in stream_url:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setMimeType('application/dash+xml')
        li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, li)
