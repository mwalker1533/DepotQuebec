# -*- coding: utf-8 -*-
"""
http.py — HTTP utility for ICI Tou.TV Kodi addon.
Python 3 / Kodi 20+ compatible. Replaces old GET_HTML / GET_HTML_AUTH functions.
"""

import json
import urllib.request
import urllib.error
import urllib.parse
import xbmc

REQUEST_TIMEOUT = 15  # seconds

# Headers that mimic a modern browser — prevents 403 / 426 errors
DEFAULT_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/html, */*',
    'Accept-Language': 'fr-CA,fr;q=0.9,en;q=0.8',
    'Origin': 'https://ici.tou.tv',
    'Referer': 'https://ici.tou.tv/',
}


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[Tou.TV] {msg}', level)


def get(url, is_json=False, auth_token=None, extra_headers=None):
    """
    Perform a GET request and return content.

    Args:
        url (str): URL to fetch.
        is_json (bool): Parse and return as dict/list if True.
        auth_token (str): Optional Bearer token for authenticated requests.
        extra_headers (dict): Optional additional headers.

    Returns:
        str | dict | list | None
    """
    headers = dict(DEFAULT_HEADERS)
    if auth_token:
        headers['Authorization'] = f'Bearer {auth_token}'
    if extra_headers:
        headers.update(extra_headers)

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            raw = resp.read().decode('utf-8')
            if is_json:
                return json.loads(raw)
            return raw

    except urllib.error.HTTPError as e:
        _log(f'HTTP {e.code} error fetching {url}: {e.reason}', xbmc.LOGERROR)
    except urllib.error.URLError as e:
        _log(f'URL error fetching {url}: {e.reason}', xbmc.LOGERROR)
    except json.JSONDecodeError as e:
        _log(f'JSON parse error for {url}: {e}', xbmc.LOGERROR)
    except Exception as e:
        _log(f'Unexpected error fetching {url}: {e}', xbmc.LOGERROR)

    return None


def post(url, data, is_json=False, auth_token=None):
    """
    Perform a POST request and return content.

    Args:
        url (str): URL to post to.
        data (dict): POST body as a dict (will be JSON-encoded).
        is_json (bool): Parse and return response as dict/list if True.
        auth_token (str): Optional Bearer token.

    Returns:
        str | dict | list | None
    """
    headers = dict(DEFAULT_HEADERS)
    headers['Content-Type'] = 'application/json'
    if auth_token:
        headers['Authorization'] = f'Bearer {auth_token}'

    try:
        body = json.dumps(data).encode('utf-8')
        req = urllib.request.Request(url, data=body, headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            raw = resp.read().decode('utf-8')
            if is_json:
                return json.loads(raw)
            return raw

    except urllib.error.HTTPError as e:
        _log(f'HTTP {e.code} error posting to {url}: {e.reason}', xbmc.LOGERROR)
    except urllib.error.URLError as e:
        _log(f'URL error posting to {url}: {e.reason}', xbmc.LOGERROR)
    except json.JSONDecodeError as e:
        _log(f'JSON parse error for {url}: {e}', xbmc.LOGERROR)
    except Exception as e:
        _log(f'Unexpected error posting to {url}: {e}', xbmc.LOGERROR)

    return None
