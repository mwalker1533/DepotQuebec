# -*- coding: utf-8 -*-
"""
navig.py — Navigation and playback for TVA+ Kodi addon.
Python 3 / Kodi 20+ compatible.
"""

import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import html

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
PLUGIN_URL = sys.argv[0]
PLUGIN_HANDLE = int(sys.argv[1])

# TVA+ / QUB API base URLs
API_BASE = 'https://services.radio-canada.ca/media/meta/v1'
QUB_API = 'https://api.qub.ca/api'
LIVE_URL = 'https://www.qub.ca/tvaplus/direct'


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[TVA+] {msg}', level)


def _show_error(msg):
    """Display a user-friendly error dialog."""
    xbmcgui.Dialog().ok(ADDON.getLocalizedString(32000), msg)


def build_url(params):
    """Build a plugin:// URL from a dict of params."""
    return PLUGIN_URL + '?' + urllib.parse.urlencode(params)


def add_directory_item(label, params, art=None, info=None, is_folder=True, add_favourite=False, favourite_label=None):
    """Helper to add a single item to the Kodi directory listing."""
    url = build_url(params)
    li = xbmcgui.ListItem(label)

    if art:
        li.setArt(art)

    if info:
        li.setInfo('video', info)

    # Add context menu with "Add to favourites" for shows
    if add_favourite:
        fav_label = favourite_label or label
        context_items = [
            (
                f'Ajouter "{fav_label}" aux favoris',
                f'Action(AddFavourite)',
            )
        ]
        li.addContextMenuItems(context_items)

    xbmcplugin.addDirectoryItem(
        handle=PLUGIN_HANDLE,
        url=url,
        listitem=li,
        isFolder=is_folder
    )


def show_main_menu():
    """Display the main menu."""
    items = [
        (ADDON.getLocalizedString(32001), {'action': 'live'}),       # En direct
        (ADDON.getLocalizedString(32002), {'action': 'catchup'}),    # Rattrapage
        (ADDON.getLocalizedString(32003), {'action': 'shows'}),      # Émissions
        (ADDON.getLocalizedString(32004), {'action': 'themes'}),     # Thématiques
    ]
    for label, params in items:
        add_directory_item(label, params)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_live():
    """Show the TVA live stream."""
    _log('Loading live stream')

    # Fetch live stream info from QUB API
    data = html.get_url_txt(
        f'{QUB_API}/channels?platform=web',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))  # Network error message
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    channels = data if isinstance(data, list) else data.get('channels', [])

    for channel in channels:
        if not isinstance(channel, dict):
            continue

        label = channel.get('name') or channel.get('title') or 'TVA'
        stream_url = channel.get('streamUrl') or channel.get('stream_url', '')
        thumb = channel.get('image') or channel.get('thumbnail', '')

        if not stream_url:
            continue

        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setInfo('video', {'title': label, 'mediatype': 'video'})

        # Set up InputStream Adaptive for HLS streams
        if '.m3u8' in stream_url:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/x-mpegURL')
            li.setContentLookup(False)

        xbmcplugin.addDirectoryItem(
            handle=PLUGIN_HANDLE,
            url=stream_url,
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_catchup():
    """Show recent catchup episodes grouped by show."""
    _log('Loading catchup')

    data = html.get_url_txt(
        f'{QUB_API}/catchup?platform=web&limit=50',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    episodes = data if isinstance(data, list) else data.get('items', data.get('episodes', []))

    if not episodes:
        _show_error(ADDON.getLocalizedString(32011))  # No content found
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    for ep in episodes:
        if not isinstance(ep, dict):
            continue

        title = ep.get('title') or ep.get('name', 'Sans titre')
        show = ep.get('showTitle') or ep.get('show', '')
        label = f'{show} - {title}' if show else title
        thumb = ep.get('image') or ep.get('thumbnail', '')
        desc = ep.get('description') or ep.get('summary', '')
        video_id = ep.get('id') or ep.get('videoId', '')

        if not video_id:
            continue

        add_directory_item(
            label=label,
            params={'action': 'play', 'video_id': video_id},
            art={'thumb': thumb, 'fanart': thumb},
            info={'title': title, 'plot': desc, 'mediatype': 'episode'},
            is_folder=False
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_shows():
    """List all shows available on TVA+."""
    _log('Loading shows list')

    data = html.get_url_txt(
        f'{QUB_API}/shows?platform=web&limit=200',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    shows = data if isinstance(data, list) else data.get('items', data.get('shows', []))

    for show in shows:
        if not isinstance(show, dict):
            continue

        title = show.get('title') or show.get('name', 'Sans titre')
        thumb = show.get('image') or show.get('thumbnail', '')
        desc = show.get('description') or show.get('summary', '')
        show_id = show.get('id') or show.get('showId', '')

        if not show_id:
            continue

        add_directory_item(
            label=title,
            params={'action': 'episodes', 'show_id': show_id},
            art={'thumb': thumb, 'fanart': thumb},
            info={'title': title, 'plot': desc, 'mediatype': 'tvshow'},
            add_favourite=True,
            favourite_label=title,
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'tvshows')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_episodes(show_id):
    """List episodes for a given show."""
    _log(f'Loading episodes for show {show_id}')

    data = html.get_url_txt(
        f'{QUB_API}/shows/{show_id}/episodes?platform=web',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    episodes = data if isinstance(data, list) else data.get('items', data.get('episodes', []))

    for ep in episodes:
        if not isinstance(ep, dict):
            continue

        title = ep.get('title') or ep.get('name', 'Sans titre')
        thumb = ep.get('image') or ep.get('thumbnail', '')
        desc = ep.get('description') or ep.get('summary', '')
        video_id = ep.get('id') or ep.get('videoId', '')
        season = ep.get('season', 0)
        episode = ep.get('episode', 0)

        if not video_id:
            continue

        add_directory_item(
            label=title,
            params={'action': 'play', 'video_id': video_id},
            art={'thumb': thumb, 'fanart': thumb},
            info={
                'title': title,
                'plot': desc,
                'season': season,
                'episode': episode,
                'mediatype': 'episode'
            },
            is_folder=False
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_themes():
    """Show thematic content categories."""
    _log('Loading themes')

    data = html.get_url_txt(
        f'{QUB_API}/themes?platform=web',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    themes = data if isinstance(data, list) else data.get('items', data.get('themes', []))

    for theme in themes:
        if not isinstance(theme, dict):
            continue

        title = theme.get('title') or theme.get('name', 'Sans titre')
        thumb = theme.get('image') or theme.get('thumbnail', '')
        theme_id = theme.get('id', '')

        if not theme_id:
            continue

        add_directory_item(
            label=title,
            params={'action': 'theme_videos', 'theme_id': theme_id},
            art={'thumb': thumb},
        )

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def show_theme_videos(theme_id):
    """Show videos within a theme."""
    _log(f'Loading videos for theme {theme_id}')

    data = html.get_url_txt(
        f'{QUB_API}/themes/{theme_id}/videos?platform=web',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    videos = data if isinstance(data, list) else data.get('items', data.get('videos', []))

    for vid in videos:
        if not isinstance(vid, dict):
            continue

        title = vid.get('title') or vid.get('name', 'Sans titre')
        thumb = vid.get('image') or vid.get('thumbnail', '')
        desc = vid.get('description') or vid.get('summary', '')
        video_id = vid.get('id') or vid.get('videoId', '')

        if not video_id:
            continue

        add_directory_item(
            label=title,
            params={'action': 'play', 'video_id': video_id},
            art={'thumb': thumb},
            info={'title': title, 'plot': desc, 'mediatype': 'video'},
            is_folder=False
        )

    xbmcplugin.setContent(PLUGIN_HANDLE, 'videos')
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


def play_video(video_id):
    """Resolve and play a video by ID."""
    _log(f'Resolving video {video_id}')

    # Fetch playback URL from QUB API
    data = html.get_url_txt(
        f'{QUB_API}/videos/{video_id}/streams?platform=web',
        is_json=True
    )

    if not data:
        _show_error(ADDON.getLocalizedString(32010))
        return

    # Try to extract stream URL from common response shapes
    stream_url = None
    if isinstance(data, dict):
        stream_url = (
            data.get('url') or
            data.get('streamUrl') or
            data.get('stream_url') or
            data.get('hlsUrl') or
            data.get('hls_url')
        )
        # Sometimes nested under a 'stream' or 'media' key
        if not stream_url:
            stream = data.get('stream') or data.get('media') or {}
            stream_url = stream.get('url') or stream.get('hlsUrl', '')

    if not stream_url:
        _log(f'Could not find stream URL in response: {data}', xbmc.LOGERROR)
        _show_error(ADDON.getLocalizedString(32012))  # Video unavailable
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'mediatype': 'video'})

    # Use InputStream Adaptive for HLS/DASH streams
    if '.m3u8' in stream_url:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
    elif '.mpd' in stream_url:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        li.setMimeType('application/dash+xml')
        li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, li)
