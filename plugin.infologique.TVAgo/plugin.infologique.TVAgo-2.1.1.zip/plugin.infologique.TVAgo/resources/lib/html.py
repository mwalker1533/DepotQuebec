# -*- coding: utf-8 -*-
"""
html.py — HTTP utility for TVA+ Kodi addon.
Python 3 / Kodi 20+ compatible. Replaces urllib2 with urllib.request.
"""

import json
import urllib.request
import urllib.error
import xbmc

# Browser-like headers to avoid 403 errors (the main bug on Raspberry Pi)
DEFAULT_HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    ),
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'fr-CA,fr;q=0.9,en;q=0.8',
    'Origin': 'https://www.qub.ca',
    'Referer': 'https://www.qub.ca/',
}

REQUEST_TIMEOUT = 15  # seconds


def get_url_txt(url, is_json=False, extra_headers=None):
    """
    Fetch a URL and return its content as a string.
    Returns None on error instead of crashing.

    Args:
        url (str): The URL to fetch.
        is_json (bool): If True, parse and return as dict/list. Otherwise return raw string.
        extra_headers (dict): Optional additional headers to merge.

    Returns:
        str | dict | list | None
    """
    headers = dict(DEFAULT_HEADERS)
    if extra_headers:
        headers.update(extra_headers)

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
            raw = response.read().decode('utf-8')
            if is_json:
                return json.loads(raw)
            return raw

    except urllib.error.HTTPError as e:
        xbmc.log(
            f'[TVA+] HTTP error fetching {url}: {e.code} {e.reason}',
            xbmc.LOGERROR
        )
    except urllib.error.URLError as e:
        xbmc.log(
            f'[TVA+] URL error fetching {url}: {e.reason}',
            xbmc.LOGERROR
        )
    except json.JSONDecodeError as e:
        xbmc.log(
            f'[TVA+] JSON parse error for {url}: {e}',
            xbmc.LOGERROR
        )
    except Exception as e:
        xbmc.log(
            f'[TVA+] Unexpected error fetching {url}: {e}',
            xbmc.LOGERROR
        )

    return None
