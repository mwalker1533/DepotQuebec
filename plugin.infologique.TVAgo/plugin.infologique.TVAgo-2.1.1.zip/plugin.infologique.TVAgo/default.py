# -*- coding: utf-8 -*-
"""
default.py — Entry point for TVA+ Kodi addon.
Python 3 / Kodi 20+ compatible.
"""

import sys
import urllib.parse

from resources.lib import navig


def main():
    """Parse URL parameters and route to the correct function."""
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        query = sys.argv[2].lstrip('?')
        params = dict(urllib.parse.parse_qsl(query))

    action = params.get('action', '')

    if action == 'live':
        navig.show_live()

    elif action == 'catchup':
        navig.show_catchup()

    elif action == 'shows':
        navig.show_shows()

    elif action == 'episodes':
        show_id = params.get('show_id', '')
        if show_id:
            navig.show_episodes(show_id)

    elif action == 'themes':
        navig.show_themes()

    elif action == 'theme_videos':
        theme_id = params.get('theme_id', '')
        if theme_id:
            navig.show_theme_videos(theme_id)

    elif action == 'play':
        video_id = params.get('video_id', '')
        if video_id:
            navig.play_video(video_id)

    else:
        navig.show_main_menu()


if __name__ == '__main__':
    main()
